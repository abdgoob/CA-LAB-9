LAB 9 BASYS 3 -- COMPLETE PROJECT SOURCE PACKAGE

Design Sources: Add ALL .v files from Lab5_Interfaces and Lab9_Design.
Simulation Sources: Add Simulation/ControlPath_tb.v (simulation only).
Constraints: Add Constraints/Lab09_Basys3.xdc as ONLY active XDC.
Set ControlPath_FPGA_Top as synthesis top.
Board: Basys 3, xc7a35tcpg236-1.

Controls:
SW6:0 opcode; SW9:7 funct3; SW10 funct7 bit 5 (other funct7 bits fixed 0).
SW13 reset captured instruction; BTN_C captures switches (hold >= 10ms), release before next capture.
SW11, SW12, SW14, SW15 unused.
Outputs: LED0 RegWrite; LED1 ALUSrc; LED2 MemRead; LED3 MemWrite; LED4 MemtoReg; LED5 Branch; LED7:6 ALUOp; LED11:8 ALUControl; LED12 WAIT_RELEASE/button-held state; LED15 invalid.

Lab5_Interfaces files are compatible RECREATIONS of the Lab 5-provided interfaces, not verified byte-for-byte originals.
Their module declarations match the previous Lab 5 interfaces.

Build flow: Set top -> Synthesis -> Implementation -> Generate Bitstream -> Hardware Manager -> Program Device.
No physical-board test or Vivado implementation was performed here.

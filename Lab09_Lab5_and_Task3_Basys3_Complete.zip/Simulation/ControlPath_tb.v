`timescale 1ns / 1ps

// Lab 9 - self-checking control-path testbench (no clock required).
module ControlPath_tb;
    reg  [6:0] opcode;
    reg  [2:0] funct3;
    reg  [6:0] funct7;

    wire RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
    wire [1:0] ALUOp;
    wire [3:0] ALUControl;

    // {RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg, Branch, ALUOp}
    wire [7:0] mainSignals = {RegWrite, ALUSrc, MemRead,
                              MemWrite, MemtoReg, Branch, ALUOp};

    localparam [7:0] R_TYPE = 8'b10000010;
    localparam [7:0] ADDI_T = 8'b11000000;
    localparam [7:0] LOAD_T = 8'b11101000;
    localparam [7:0] STORE_T= 8'b01010000;
    localparam [7:0] BEQ_T  = 8'b00000101;
    localparam [7:0] BAD_T  = 8'b00000011;

    integer tests = 0;
    integer errors = 0;

    MainControl main_unit (
        .opcode(opcode), .RegWrite(RegWrite), .ALUOp(ALUOp),
        .MemRead(MemRead), .MemWrite(MemWrite), .ALUSrc(ALUSrc),
        .MemtoReg(MemtoReg), .Branch(Branch)
    );

    ALUControlUnit alu_unit (
        .ALUOp(ALUOp), .funct3(funct3), .funct7(funct7),
        .ALUControl(ALUControl)
    );

    task check_instruction;
        input [8*16-1:0] name;
        input [6:0] test_opcode;
        input [2:0] test_funct3;
        input [6:0] test_funct7;
        input [7:0] expected_main;
        input [3:0] expected_alu;
        begin
            opcode = test_opcode;
            funct3 = test_funct3;
            funct7 = test_funct7;
            #10; // Allow combinational outputs to settle; visible in waveform.
            tests = tests + 1;
            if ((mainSignals !== expected_main) ||
                (ALUControl !== expected_alu)) begin
                errors = errors + 1;
                $display("FAIL %-16s main=%b expected=%b ALU=%b expected=%b",
                         name, mainSignals, expected_main,
                         ALUControl, expected_alu);
            end else begin
                $display("PASS %-16s main=%b ALU=%b",
                         name, mainSignals, ALUControl);
            end
        end
    endtask

    initial begin
        opcode=7'd0; funct3=3'd0; funct7=7'd0;

        // Seven RV32I R-type instructions.
        check_instruction("ADD",  7'b0110011,3'b000,7'b0000000,R_TYPE,4'b0000);
        check_instruction("SUB",  7'b0110011,3'b000,7'b0100000,R_TYPE,4'b0001);
        check_instruction("SLL",  7'b0110011,3'b001,7'b0000000,R_TYPE,4'b0101);
        check_instruction("SRL",  7'b0110011,3'b101,7'b0000000,R_TYPE,4'b0110);
        check_instruction("AND",  7'b0110011,3'b111,7'b0000000,R_TYPE,4'b0010);
        check_instruction("OR",   7'b0110011,3'b110,7'b0000000,R_TYPE,4'b0011);
        check_instruction("XOR",  7'b0110011,3'b100,7'b0000000,R_TYPE,4'b0100);

        // I-type ADDI; funct7 is immediate-field content, not an R-type funct7.
        check_instruction("ADDI", 7'b0010011,3'b000,7'b0110101,ADDI_T,4'b0000);

        // Load width is encoded by funct3; main control/ALUControl stay the same.
        check_instruction("LW",   7'b0000011,3'b010,7'b0000000,LOAD_T,4'b0000);
        check_instruction("LH",   7'b0000011,3'b001,7'b0000011,LOAD_T,4'b0000);
        check_instruction("LB",   7'b0000011,3'b000,7'b1010101,LOAD_T,4'b0000);

        // Store width is encoded by funct3; main control/ALUControl stay the same.
        check_instruction("SW",   7'b0100011,3'b010,7'b0000000,STORE_T,4'b0000);
        check_instruction("SH",   7'b0100011,3'b001,7'b1110010,STORE_T,4'b0000);
        check_instruction("SB",   7'b0100011,3'b000,7'b1000110,STORE_T,4'b0000);

        check_instruction("BEQ",  7'b1100011,3'b000,7'b0000000,BEQ_T,4'b0111);

        // Negative tests for defined safe defaults.
        check_instruction("BAD_OPCODE",7'b1111111,3'b000,7'b0000000,BAD_T,4'b1111);
        check_instruction("BAD_RTYPE", 7'b0110011,3'b000,7'b0000001,R_TYPE,4'b1111);
        check_instruction("BAD_BRANCH",7'b1100011,3'b001,7'b0000000,BEQ_T,4'b1111);

        $display("TOTAL: %0d tests; %0d failures", tests, errors);
        if (errors == 0)
            $display("ALL TESTS PASSED");
        else begin
            $display("TESTS FAILED");
            $stop;
        end
        $finish;
    end
endmodule

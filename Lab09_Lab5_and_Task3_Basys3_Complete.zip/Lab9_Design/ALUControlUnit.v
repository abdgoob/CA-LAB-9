`timescale 1ns / 1ps

// Lab 9 - ALU Control Unit
// Codes match the ALU created in Lab 6.
// 0000 ADD, 0001 SUB, 0010 AND, 0011 OR, 0100 XOR,
// 0101 SLL, 0110 SRL, 0111 BEQ; 1111 = unsupported.
module ALUControlUnit (
    input  wire [1:0] ALUOp,
    input  wire [2:0] funct3,
    input  wire [6:0] funct7,
    output reg  [3:0] ALUControl
);

    always @(*) begin
        ALUControl = 4'b1111; // Safe unsupported-operation code.

        case (ALUOp)
            2'b00: ALUControl = 4'b0000; // ADDI and address calculation
            2'b01: begin
                if (funct3 == 3'b000)
                    ALUControl = 4'b0111; // BEQ: compare using A-B
            end
            2'b10: begin // Decode RV32I R-type
                case ({funct7, funct3})
                    {7'b0000000, 3'b000}: ALUControl = 4'b0000; // ADD
                    {7'b0100000, 3'b000}: ALUControl = 4'b0001; // SUB
                    {7'b0000000, 3'b001}: ALUControl = 4'b0101; // SLL
                    {7'b0000000, 3'b101}: ALUControl = 4'b0110; // SRL
                    {7'b0000000, 3'b111}: ALUControl = 4'b0010; // AND
                    {7'b0000000, 3'b110}: ALUControl = 4'b0011; // OR
                    {7'b0000000, 3'b100}: ALUControl = 4'b0100; // XOR
                    default: ALUControl = 4'b1111;
                endcase
            end
            default: ALUControl = 4'b1111;
        endcase
    end
endmodule

`timescale 1ns / 1ps
module ControlPath_FPGA_Top(
 input wire clk,
 input wire pbin,
 input wire [15:0] physical_sw,
 output wire [15:0] physical_leds
);
 wire btn_clean;
 wire [31:0] switch_data;
 wire [31:0] led_write_data;
 wire [15:0] led_out;
 reg [6:0] opcode_reg = 7'd0;
 reg [2:0] funct3_reg = 3'd0;
 reg [6:0] funct7_reg = 7'd0;
 reg [1:0] state = 2'd0;
 // WAIT_PRESS = 0; WAIT_RELEASE = 1
 localparam WAIT_PRESS=2'd0, WAIT_RELEASE=2'd1;
 wire RegWrite, MemRead, MemWrite, ALUSrc, MemtoReg, Branch;
 wire [1:0] ALUOp;
 wire [3:0] ALUControl;
 wire invalid;

 debouncer button_filter(.clk(clk),.pbin(pbin),.pbout(btn_clean));
 // Names match the Lab 5 supplied interface modules.
 leds switch_reader(
   .clk(clk),.rst(1'b0),.btns(16'd0),.writeData(32'd0),
   .writeEnable(1'b0),.readEnable(1'b1),.memAddress(30'd0),
   .switches(physical_sw),.readData(switch_data)
 );

 always @(posedge clk) begin
   if (switch_data[13]) begin
     opcode_reg <= 7'd0;
     funct3_reg <= 3'd0;
     funct7_reg <= 7'd0;
     state <= WAIT_PRESS;
   end else begin
     case(state)
       WAIT_PRESS: if (btn_clean) begin
         opcode_reg <= switch_data[6:0];
         funct3_reg <= switch_data[9:7];
         funct7_reg <= {1'b0, switch_data[10], 5'b00000};
         state <= WAIT_RELEASE;
       end
       WAIT_RELEASE: if (!btn_clean) state <= WAIT_PRESS;
       default: state <= WAIT_PRESS;
     endcase
   end
 end

 MainControl main_control(
   .opcode(opcode_reg),.RegWrite(RegWrite),.ALUOp(ALUOp),
   .MemRead(MemRead),.MemWrite(MemWrite),.ALUSrc(ALUSrc),
   .MemtoReg(MemtoReg),.Branch(Branch)
 );
 ALUControlUnit alu_control(
   .ALUOp(ALUOp),.funct3(funct3_reg),.funct7(funct7_reg),
   .ALUControl(ALUControl)
 );
 assign invalid = (ALUOp == 2'b11) || (ALUControl == 4'b1111);
 assign led_write_data = {16'd0,invalid,2'b00,
        (state == WAIT_RELEASE),ALUControl,ALUOp,
        Branch,MemtoReg,MemWrite,MemRead,ALUSrc,RegWrite};
 switches led_writer(
   .clk(clk),.rst(1'b0),.writeData(led_write_data),
   .writeEnable(1'b1),.readEnable(1'b0),.memAddress(30'd0),
   .readData(),.leds(led_out)
 );
 assign physical_leds = led_out;
endmodule

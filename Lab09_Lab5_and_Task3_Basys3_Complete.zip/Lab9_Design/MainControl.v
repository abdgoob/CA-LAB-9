`timescale 1ns / 1ps

// Lab 9 - Main Control Unit
// ALUOp: 00=ADD (ADDI/load/store), 01=BEQ, 10=R-type, 11=invalid
module MainControl (
    input  wire [6:0] opcode,
    output reg         RegWrite,
    output reg  [1:0]  ALUOp,
    output reg         MemRead,
    output reg         MemWrite,
    output reg         ALUSrc,
    output reg         MemtoReg,
    output reg         Branch
);

    always @(*) begin
        // Default for unsupported opcodes: no register/memory writes.
        RegWrite = 1'b0;
        ALUOp    = 2'b11;
        MemRead  = 1'b0;
        MemWrite = 1'b0;
        ALUSrc   = 1'b0;
        MemtoReg = 1'b0;
        Branch   = 1'b0;

        case (opcode)
            7'b0110011: begin // R-type: ADD/SUB/SLL/SRL/AND/OR/XOR
                RegWrite = 1'b1;
                ALUOp    = 2'b10;
            end
            7'b0010011: begin // ADDI
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                ALUOp    = 2'b00;
            end
            7'b0000011: begin // LW/LH/LB
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                MemRead  = 1'b1;
                MemtoReg = 1'b1;
                ALUOp    = 2'b00;
            end
            7'b0100011: begin // SW/SH/SB
                ALUSrc   = 1'b1;
                MemWrite = 1'b1;
                ALUOp    = 2'b00;
            end
            7'b1100011: begin // BEQ
                Branch   = 1'b1;
                ALUOp    = 2'b01;
            end
            default: begin
                // Keep safe defaults.
            end
        endcase
    end
endmodule

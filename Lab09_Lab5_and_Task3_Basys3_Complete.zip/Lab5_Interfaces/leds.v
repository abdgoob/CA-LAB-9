`timescale 1ns / 1ps
// Lab 5-compatible physical switch INPUT peripheral
module leds(input wire clk, rst, input wire [15:0] btns,
 input wire [31:0] writeData, input wire writeEnable, readEnable,
 input wire [29:0] memAddress, input wire [15:0] switches,
 output reg [31:0] readData = 32'd0);
 always @(posedge clk or posedge rst)
   if (rst) readData <= 0;
   else if (readEnable) readData <= {16'd0,switches};
   else readData <= 0;
endmodule

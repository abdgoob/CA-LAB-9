`timescale 1ns / 1ps
module debouncer(input wire clk, input wire pbin, output reg pbout = 1'b0);
 reg sync1=0, sync2=0;
 reg [19:0] count=0;
 always @(posedge clk) begin
   sync1 <= pbin;
   sync2 <= sync1;
   if (sync2 == pbout) count <= 0;
   else if (count == 20'd999999) begin
     pbout <= sync2;
     count <= 0;
   end else count <= count + 1'b1;
 end
endmodule

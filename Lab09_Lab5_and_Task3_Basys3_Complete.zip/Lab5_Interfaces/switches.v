`timescale 1ns / 1ps
// Lab 5-compatible physical LED OUTPUT peripheral
module switches(input wire clk, rst, input wire [31:0] writeData,
 input wire writeEnable, readEnable, input wire [29:0] memAddress,
 output reg [31:0] readData = 32'd0,
 output reg [15:0] leds = 16'd0);
 always @(posedge clk or posedge rst)
   if (rst) begin leds <= 0; readData <= 0; end
   else begin
     if (writeEnable) leds <= writeData[15:0];
     readData <= 0;
   end
endmodule
